# Campfire icons

121 line icons drawn for Campfire, plus the app icons and the brand mark.

Open `preview.png` (or `preview.html`) to see the whole set with names.

## What's here

    svg/                    121 icons, one file each, named as the app names them
    campfire-icons.svg      the same set as one sprite sheet of <symbol>s
    icons.json              raw path data plus the category grouping
    preview.html / .png     contact sheet of everything
    app-icons/              the PWA/home-screen icons and the favicon
    brand/logo-mark.png     the flame on its own, transparent

## How they're built

Every icon is drawn on a **24×24** grid and stroked at **1.75**, round caps and
joins, with **no fill**. They stroke with `currentColor`, so an icon takes the
colour of whatever it sits in — that is how one set of drawings covers all four
of the app's themes. Opened on their own they render black.

    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"
         stroke-linecap="round" stroke-linejoin="round"> …path data… </svg>

From the sprite sheet:

    <svg class="ico"><use href="campfire-icons.svg#sword"/></svg>

Most icons carry a `<g transform>` they were not drawn with, put there by a
fitting pass that does two things.

**It centres them on their visual weight, not their bounding box.** Those are
not the same point and the eye follows the weight. The sparkle is the clearest
case: a big four-pointed star with a small one trailing off the corner, so its
box centre falls between the two and box-centring shoves the big star — the part
anyone actually sees — off to one side. Two thirds of the set had its mass more
than half a unit off the box centre: invisible on one icon, obvious the moment
forty are stacked down a list.

**And it evens out their size, to the set's own median.** The target is measured
rather than chosen, which matters more than it sounds: an earlier version of this
pass fitted to a picked number and shrank 111 of the 121 icons by a tenth. It was
perfectly even and visibly smaller. Normalising to the median pulls the outliers
in from both ends and leaves the middle exactly where it was. Where fitting means
scaling, the group carries a compensating `stroke-width`, because scaling a
stroked path scales its stroke too and an uneven line weight is worse than the
unevenness being fixed.

If you add one, run it through the same pass; an icon placed by hand will sit at
the wrong size and the wrong place next to the rest.

## Drawn for 24px

These were designed at the size they are used: 18–24px next to a name, 32 in a
picker. Anything that needed more detail than that to read was cut rather than
shipped as a smudge, which is why there is no crossbow, halberd or gauntlet —
each was drawn several times, never read as itself at 24px, and the app maps
those names onto a near neighbour instead (a crossbow gets the bow).

## Origin

Drawn from scratch for this project. No icon library was copied or imported, and
there is no third-party licence attached to any of them.
